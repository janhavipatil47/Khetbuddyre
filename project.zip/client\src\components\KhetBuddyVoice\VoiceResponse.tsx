import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Volume2, VolumeX } from "lucide-react";

interface VoiceResponseProps {
  response: string;
  isProcessing: boolean;
}

const VoiceResponse = ({ response, isProcessing }: VoiceResponseProps) => {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [speech, setSpeech] = useState<SpeechSynthesisUtterance | null>(null);

  useEffect(() => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance();
      utterance.rate = 1.0;
      utterance.pitch = 1.0;
      utterance.volume = 1.0;
      utterance.lang = 'en-US'; // Default language
      
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);
      
      setSpeech(utterance);
    }
    
    return () => {
      if (speech) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);
  
  const handleSpeak = () => {
    if (speech && response) {
      speech.text = response;
      window.speechSynthesis.cancel(); // Cancel any ongoing speech
      window.speechSynthesis.speak(speech);
    }
  };
  
  const handleStop = () => {
    window.speechSynthesis.cancel();
    setIsSpeaking(false);
  };
  
  if (isProcessing) {
    return (
      <div className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
        <div className="flex items-center justify-center">
          <div className="animate-pulse flex space-x-1">
            <div className="h-2 w-2 bg-gray-400 rounded-full"></div>
            <div className="h-2 w-2 bg-gray-400 rounded-full"></div>
            <div className="h-2 w-2 bg-gray-400 rounded-full"></div>
          </div>
          <span className="ml-2 text-gray-500">Processing...</span>
        </div>
      </div>
    );
  }
  
  return (
    <div className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
      <div className="flex justify-between items-start">
        <div className="flex-1">
          <p className="text-gray-800">{response}</p>
        </div>
        {response && (
          <Button
            onClick={isSpeaking ? handleStop : handleSpeak}
            variant="ghost"
            size="sm"
            className="ml-2"
          >
            {isSpeaking ? (
              <VolumeX className="h-5 w-5 text-gray-500" />
            ) : (
              <Volume2 className="h-5 w-5 text-gray-500" />
            )}
          </Button>
        )}
      </div>
    </div>
  );
};

export default VoiceResponse; 