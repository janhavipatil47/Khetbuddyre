import { useState } from "react";
import { motion } from "framer-motion";
import { useTranslation } from "react-i18next";
import { MessageSquare } from "lucide-react";

import ChatButton from "@/components/CropChatAI/ChatButton";
import ChatModal from "@/components/CropChatAI/ChatModal";

interface Message {
  id: string;
  content: string;
  role: "user" | "assistant";
  timestamp?: Date;
}

const CropChatAI = () => {
  const { t } = useTranslation();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const handleSendMessage = async (content: string) => {
    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      content,
      role: "user",
      timestamp: new Date(),
    };
    setMessages((prev) => [...prev, userMessage]);

    // Show loading indicator
    setIsLoading(true);

    try {
      // Make API call to the backend
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ message: content }),
      });

      if (!response.ok) {
        throw new Error("Failed to get response");
      }

      const data = await response.json();

      // Add assistant message
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: data.response,
        role: "assistant",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      console.error("Error sending message:", error);
      // Add error message
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: "Sorry, I encountered an error. Please try again.",
        role: "assistant",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl mx-auto"
        >
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Chat Assistant
          </h1>
          <p className="text-lg text-gray-600 mb-8">
            Your intelligent companion for crop marketplace insights and supply chain guidance.
          </p>

          {/* Chat Interface */}
          <div className="relative">
            <ChatModal
              isOpen={isOpen}
              onClose={() => setIsOpen(false)}
              messages={messages}
              onSendMessage={handleSendMessage}
              isLoading={isLoading}
            />
            <div className="fixed bottom-8 right-8">
              <ChatButton isOpen={isOpen} onClick={() => setIsOpen(!isOpen)} />
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default CropChatAI; 