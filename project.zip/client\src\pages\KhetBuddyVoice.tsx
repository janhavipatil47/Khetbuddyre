import { useState } from "react";
import { useTranslation } from "react-i18next";
import { Mic, MicOff } from "lucide-react";

import VoiceInput from "../components/KhetBuddyVoice/VoiceInput";
import VoiceResponse from "../components/KhetBuddyVoice/VoiceResponse";

interface KhetBuddyVoiceProps {
  currentUser: {
    id: number;
    name: string;
    location: string;
    role: string;
  };
}

const KhetBuddyVoice = ({ currentUser }: KhetBuddyVoiceProps) => {
  const { t } = useTranslation();
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [response, setResponse] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);

  const handleStartListening = () => {
    setIsListening(true);
    setTranscript("");
    setResponse("");
  };

  const handleStopListening = (text: string) => {
    setIsListening(false);
    setTranscript(text);
    setIsProcessing(true);
    
    // Simulate API call to get response
    setTimeout(() => {
      setResponse("Based on your question about " + text + ", I recommend checking the soil moisture levels and considering adding organic fertilizer. Would you like more specific information about crop rotation for your region?");
      setIsProcessing(false);
    }, 2000);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          Voice Assistant
        </h1>
        <p className="text-lg text-gray-600 mb-8">
          Your voice-enabled companion for crop marketplace insights and supply chain guidance.
        </p>
        
        <div className="flex flex-col md:flex-row gap-6">
          <div className="flex-1">
            <h2 className="text-xl font-semibold mb-4">{t('khetbuddyvoice.features', 'Features')}</h2>
            <ul className="space-y-3">
              <li className="flex items-start">
                <Mic className="h-5 w-5 mr-2 text-green-600 mt-0.5" />
                <span>{t('khetbuddyvoice.feature1', 'Voice-activated farming assistant')}</span>
              </li>
              <li className="flex items-start">
                <Mic className="h-5 w-5 mr-2 text-green-600 mt-0.5" />
                <span>{t('khetbuddyvoice.feature2', 'Get hands-free access to farming information')}</span>
              </li>
              <li className="flex items-start">
                <Mic className="h-5 w-5 mr-2 text-green-600 mt-0.5" />
                <span>{t('khetbuddyvoice.feature3', 'Perfect for farmers working in the field')}</span>
              </li>
              <li className="flex items-start">
                <Mic className="h-5 w-5 mr-2 text-green-600 mt-0.5" />
                <span>{t('khetbuddyvoice.feature4', 'Supports multiple languages and dialects')}</span>
              </li>
            </ul>
          </div>
          
          <div className="flex-1">
            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-medium mb-4">{t('khetbuddyvoice.try', 'Try it now')}</h3>
              
              <div className="mb-6">
                <VoiceInput 
                  isListening={isListening}
                  onStartListening={handleStartListening}
                  onStopListening={handleStopListening}
                />
              </div>
              
              {transcript && (
                <div className="mb-4">
                  <h4 className="text-sm font-medium text-gray-500 mb-2">{t('khetbuddyvoice.youSaid', 'You said:')}</h4>
                  <p className="bg-white p-3 rounded border">{transcript}</p>
                </div>
              )}
              
              {(isProcessing || response) && (
                <div>
                  <h4 className="text-sm font-medium text-gray-500 mb-2">{t('khetbuddyvoice.response', 'Response:')}</h4>
                  <VoiceResponse 
                    response={response} 
                    isProcessing={isProcessing} 
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default KhetBuddyVoice; 