import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Mic, MicOff } from "lucide-react";

interface VoiceInputProps {
  isListening: boolean;
  onStartListening: () => void;
  onStopListening: (text: string) => void;
}

const VoiceInput = ({ isListening, onStartListening, onStopListening }: VoiceInputProps) => {
  const [transcript, setTranscript] = useState("");
  const [recognition, setRecognition] = useState<any>(null);

  useEffect(() => {
    // Check if browser supports speech recognition
    if ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window) {
      // @ts-ignore - SpeechRecognition is not in the TypeScript definitions
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      const recognitionInstance = new SpeechRecognition();
      
      recognitionInstance.continuous = true;
      recognitionInstance.interimResults = true;
      recognitionInstance.lang = 'en-US'; // Default language
      
      recognitionInstance.onresult = (event: any) => {
        let finalTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            finalTranscript += transcript;
          }
        }
        if (finalTranscript) {
          setTranscript(finalTranscript);
        }
      };
      
      recognitionInstance.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
      };
      
      setRecognition(recognitionInstance);
    }
    
    return () => {
      if (recognition) {
        recognition.abort();
      }
    };
  }, []);
  
  const handleStartListening = () => {
    if (recognition) {
      setTranscript("");
      recognition.start();
      onStartListening();
    } else {
      alert("Speech recognition is not supported in your browser.");
    }
  };
  
  const handleStopListening = () => {
    if (recognition) {
      recognition.stop();
      onStopListening(transcript);
    }
  };
  
  return (
    <div className="flex flex-col items-center">
      <Button
        onClick={isListening ? handleStopListening : handleStartListening}
        className={`rounded-full w-16 h-16 flex items-center justify-center ${
          isListening 
            ? "bg-red-500 hover:bg-red-600" 
            : "bg-primary hover:bg-primary/90"
        }`}
      >
        {isListening ? (
          <MicOff className="h-6 w-6 text-white" />
        ) : (
          <Mic className="h-6 w-6 text-white" />
        )}
      </Button>
      <p className="mt-2 text-sm text-gray-500">
        {isListening ? "Listening..." : "Click to speak"}
      </p>
    </div>
  );
};

export default VoiceInput; 