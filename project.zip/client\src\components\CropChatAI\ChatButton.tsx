import { motion } from "framer-motion";
import { MessageSquare, X } from "lucide-react";

interface ChatButtonProps {
  isOpen?: boolean;
  onClick: () => void;
}

const ChatButton = ({ isOpen = false, onClick }: ChatButtonProps) => {
  return (
    <motion.button
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      onClick={onClick}
      className="w-14 h-14 rounded-full bg-primary hover:bg-primary/90 text-white flex items-center justify-center shadow-md focus:outline-none focus:ring-2 focus:ring-primary focus:ring-opacity-50"
      style={{
        boxShadow: "0 4px 20px rgba(0, 0, 0, 0.15)",
      }}
    >
      {isOpen ? (
        <X className="w-6 h-6" />
      ) : (
        <MessageSquare className="w-6 h-6" />
      )}
    </motion.button>
  );
};

export default ChatButton; 